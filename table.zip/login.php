<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login - Multi-user Input in Determining Answer Sets (MIDAS)</title>
</head>
<body>
<h3>Login - Multi-user Input in Determining Answer Sets (MIDAS)</h3>
<form action="login2.php" method="post">
<p>Username:<input type="text" name="username" required/></p>
<p>Password:<input type="password" name="password" required/></p>
<input type="submit" value="Login"/><br><br>
<a href="reset.php">Forgot Password?</a> | <a href="register.php">Register</a>
</form>
</body>
</html>
