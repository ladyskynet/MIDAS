<?php

if (isset($_POST['submit1']) ) {
	print "YELOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOW";
	$v = $_POST['vote1'];
	print $v;
}
?>

