<!DOCTYPE html>
<html>
<body>


<p><a href="logout2.php">Logout</a> &nbsp; &nbsp; <a href="index.php">Main Menu</a></p>

<?php 
/*include "admin.php";
//session_abort();
session_start();
 
print "<pre>";
print_r ($_SESSION);
print "</pre>";
*/

/*
if (isset($_POST['AddData'])) {
	$_SESSION['dname'] = $_POST['dset_name'];
}
echo $_SESSION['dname'];
*/
?>
</body>
</html>
